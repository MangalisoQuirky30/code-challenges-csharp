﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CsharpExercisesLibrary
{
    public class Numbers
    {
        public string BiggestNumber(int[] intList)
        {
            string biggestInt = string.Empty;

            for (int i = 1; i < intList.Length; i++ )
            {
                if (intList[i - 1] < intList[i])
                {
                    biggestInt = "biggest number = " + intList[i];
                }
            }
            return biggestInt;
        }
        public string SecondBiggestNumber(int[] intList)
        {
           string secondBiggestInt = string.Empty;

            for (int i = 1; i < intList.Length; i++ )
            {
                if (intList[i -1] < intList[i])
                {
                    secondBiggestInt = "Second biggest number = " + intList[i - 1];
                }
            }
            return secondBiggestInt;
        } 
    }
}
