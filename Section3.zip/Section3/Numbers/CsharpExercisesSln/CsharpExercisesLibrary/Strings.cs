﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpExercisesLibrary
{
    public class Strings
    {
        public string CapitalizeEachLetter()
        {
            string text = "I hope you had a good weekend!";

            char[] textArr = text.ToCharArray();

            for(int i = 0; i < text.Length; i++)
            {
               

                    if (text[i] == ' ')
                    {
                        Console.Write($" {text[++i].ToString().ToUpper() }");
                    }else
                    Console.Write($"{text[i] }");
                
            }
            //ring newt = string.Join(" ", textArr);

            return text;
        }





        public string CapitalizeEachLetterAgain()
        {
            string text = "The task was to capitalize each word in this sentence.";

            string[] splitList = text.Split(' ');
            string word = string.Empty;
                string result = string.Empty;
                string newRes = string.Empty;


            for(int index = 0; index < splitList.Length ; index++)
            {
                word = splitList[index] ;
                char[] wordArray = word.ToCharArray() ;

                char letterUpper = char.ToUpper(word[0]) ;

                wordArray[0] = letterUpper ;
                newRes = new string(wordArray) ;
                splitList[index] = newRes ;

            }

            return result;

        }









        public string HowManyLetters()
        {
            string text = "Today is a wednesday. Happy Wednesday everybody.";
            string result = string.Empty;
            int x = 0;

            Dictionary<string, int> lettersInSentence = new Dictionary<string, int>();    

            for(int outerIndex=0; outerIndex < text.Length;outerIndex++)
            {
                var key = text[outerIndex].ToString();

                if (!lettersInSentence.ContainsKey(key))
                    lettersInSentence[key] = 0;


                lettersInSentence[key] = lettersInSentence[key] + 1;
 
            }      

            foreach(var key in lettersInSentence.Keys)
            {
                        var count = lettersInSentence[key];

                        result +=  "  \"" + key + "\"" + " -> " + count;  
            }


             for (int i = 0; i < text.Length; i++)
            {
                for(int b = 0; b < text.Length; b++ )
                {
                    if (text[i] == text[b])
                    {
                        ++x ;
                        Console.WriteLine( text[i] + "-->" + x );

                    }
                }
                x = 0 ;
                Console.WriteLine("");
            }
            return result;
        }



        public string HowManyLettersInSentence(string myStr)
        {
            string result = string.Empty;
            string resultFinal = string.Empty;
            
            char[] myStrArr = myStr.ToCharArray();
            char[] alpha = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            int[] letterCountStorage = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };


            for (int i = 0; i < alpha.Length; i++)
            {
                int letterCount = 0;
                for (int x = 0; x < myStrArr.Length; x++)
                {
                    if (alpha[i] == myStrArr[x])
                    {
                        letterCount++;
                        //result = alpha[i] + "-->" + letterCount + "  ";
                        letterCountStorage[i] = letterCount;
                    }
                }
            }

            for(int i = 0; i < letterCountStorage.Length; i++)
            {
                if(letterCountStorage[i] > 0)
                {
                    resultFinal += alpha[i] + "->" + letterCountStorage[i] + " ";
                }
            }
            return resultFinal;
        }
    }
}
