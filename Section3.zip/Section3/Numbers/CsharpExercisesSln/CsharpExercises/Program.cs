﻿using System;
using CsharpExercisesLibrary;

namespace CsharpExercises
{
    class Program 
    {
        static void Main(string[] args)
        {
            int[] intListArr = { 6, 42, 6, 31, 2, 55, 56, 23 };
            Numbers numbers = new Numbers();
            Strings strings = new Strings();


            Console.WriteLine(numbers.BiggestNumber(intListArr));
            Console.WriteLine(numbers.SecondBiggestNumber(intListArr));


           // Console.WriteLine(strings.CapitalizeEachLetterAgain());
           // string theText = Console.ReadLine();
           // Console.WriteLine(strings.HowManyLettersInSentence(theText));


        }
    }
}
