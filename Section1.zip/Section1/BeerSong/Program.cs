﻿using System;

namespace BeerSong
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 99;
            while(  i > 0 )
            {
                if(i == 1)
                {
                    Console.WriteLine( $" {i} bottle of beer on the wall, {i} bottle of beer.") ;
                    i-- ;
                    Console.WriteLine( $"Take one down and pass it around, no more bottles of beer on the wall.") ;
                    Console.WriteLine(" ") ;
                } 
                 if(i == 0)
                {
                    Console.WriteLine("No more bottles of beer on the wall, no more bottles of beer.") ;
                    Console.WriteLine(" Go to the store and buy some more, 99 bottles of beer on the wall.") ;
                }
                if (i > 1)
                {
                    Console.WriteLine( $" {i} bottles of beer on the wall, {i} bottles of beer.") ;
                    i-- ;
                    Console.WriteLine( $"Take one down and pass it around, {i} bottles of beer on the wall.") ;
                    Console.WriteLine(" ") ; 
                }
            }
        }
    }
}
