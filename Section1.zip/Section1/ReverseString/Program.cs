﻿using System;

namespace ReverseString
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine() ;
            char[] myStringArray = str.ToCharArray() ;

            Array.Reverse(myStringArray) ;

            string text = string.Join("" , myStringArray) ;
            Console.WriteLine(text) ;
        
        }
    }
}
