﻿using System;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine() ;
            char[] myStringArray = str.ToCharArray() ;

            Array.Reverse(myStringArray) ;
            string newString = string.Join("" , myStringArray) ;

            if (newString == str) 
            {
                Console.WriteLine("TRUE") ;
            } else
            {
                Console.WriteLine("FALSE") ;
            }

        }
    }
}
