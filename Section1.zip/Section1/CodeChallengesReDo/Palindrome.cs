using System;

namespace CodeChallengesReDo
{
    class Palindrome
    {
        public bool IsPalindrome(string str)
        {
            char[] word = str.ToCharArray();
            Array.Reverse(word);
            string wordRev = string.Join("",word) ;

            if (wordRev == str)
            {
                return true ;
            } else 
            {
                return false ;
            }
        }
    }
}