using System;

namespace CodeChallengesReDo
{
    class NumberToWords
    {
        public string ConvertIntToString(string numberStr)
        {
            int number = Convert.ToInt32(numberStr) ;
            char[] numberArr = numberStr.ToCharArray() ;
            int numberArrLgth = numberArr.Length ;
            string numberText = string.Empty;

            string[] zeroTo9 = {"zero" , "one" , "two" , "three" , "four" , "five" , "six" , "seven" , "eight" , "nine" } ;
            string[] TenTo19 = {"ten" , "eleven" , "twelve" , "thirteen" , "fourteen" , "fifteen" , "sixteen" , "seventeen" , "eighteen" , "nineteen" } ;
            string[] TwentyTo90 = {"" , "" , "twenty" , "thirty" , "fourty" , "fifty" , "sixty" , "seventy" , "eighty" , "ninety" } ;


            if (numberArrLgth == 2)
            {
                if (number < 20)
                {
                    numberText += TenTo19[number - 10] ;
                }

                if (number > 19)
                {
                    numberText += TwentyTo90[number/10] + " ";
                    number = (number / 10) ;
                    string newNumber = number.ToString() ;
                    numberArr = newNumber.ToCharArray() ;
                    numberArrLgth = numberArr.Length ;
                }
            }
            

            if (numberArrLgth == 1)
            {
                numberText += zeroTo9[number] ;
            }

            return numberText ;
        }
    }
}

