using System;

namespace CodeChallengesReDo
{
    class BeerSong
    {
        public void SingBeerSong()
        {
            int beerBottles = 99 ;
            int beerBottlesLeft = 98 ;
            string plural ;

            while(beerBottles > 0)
            {
                if(beerBottles > 1)
                {
                    if(beerBottlesLeft > 1)
                    {
                        plural = "bottles" ;
                    } else 
                    {
                        plural = "bottle" ;
                    }
                    Console.WriteLine($"{beerBottles} bottles of beer on the wall, {beerBottles} bottles of beer. Take one down and pass it around, {beerBottlesLeft} {plural} of beer on the wall.") ;
                    beerBottles-- ;
                    beerBottlesLeft-- ;
                }

                if(beerBottles == 1)
                {
                    Console.WriteLine($"{beerBottles} bottle of beer on the wall, {beerBottles} bottle of beer. Take one down and pass it around, no more bottles of beer on the wall.") ;
                    beerBottles-- ;
                }

                if(beerBottles == 0)
                {
                    Console.WriteLine("No more bottles of beer on the wall, no more bottles of beer.  Go to the store and buy some more, 99 bottles of beer on the wall.") ;
                }
            }
        }
    }
}