using System;

namespace CodeChallengesReDo
{
    class StringReverse
    {
        public string ReverseString(string str)
        {
            char[] strArr = str.ToCharArray() ;
            Array.Reverse(strArr) ;
            string strArrRev = string.Join("" , strArr) ;
            return strArrRev;

        }
    }
}
