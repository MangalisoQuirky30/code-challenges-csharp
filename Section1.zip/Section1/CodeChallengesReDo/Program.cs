﻿using System;
using CodeChallengesReDo ;

namespace CodeChallengesReDo
{
    class Program
    {
        static void Main(string[] args)
        {
            StringReverse str = new StringReverse();
            string str2rev = Console.ReadLine();
            string revStr = str.ReverseString(str2rev);
            Console.WriteLine(revStr);

            Palindrome pali = new Palindrome();
            string word = Console.ReadLine();
            bool palindromicity = pali.IsPalindrome(word) ;
            Console.WriteLine(palindromicity);

            BeerSong song = new BeerSong();
            song.SingBeerSong();

            NumberToWords num = new NumberToWords() ;
            string digits = Console.ReadLine() ;
            string text = num.ConvertIntToString(digits) ;
            Console.WriteLine(text) ;
        }
    }
}
