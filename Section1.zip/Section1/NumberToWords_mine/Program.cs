﻿using System;

namespace NumberToWords_mine
{
    class Program
    {
        public int ConvertToInt(char character)
        {
            int number = (int) (character - '0') ;
            return number ;
        }
        static void Main(string[] args)
        {
            string numberInp =  Console.ReadLine() ;  // get the number from user, comes as a string. dont convert it yet.
            Convert.ToInt32(numberInp) ;
            char[] numbInpArr = numberInp.ToCharArray() ; // make a character array of each of the numbers as a CHARACTER
            int numberLength = numbInpArr.Length ; // this tells how many numbers there are... e.g. 486 has three numbers
            int number = Convert.ToInt32(numberInp) ; // this converts the inputted number to an integer
            string numberText = "";

            Program name = new Program() ;
            
            string[] zereoNine = {"" , "one" , "two" , "three" , "four" , "five" , "six" , "seven" , "eight" , "nine" , } ;
            string[] tenHundred = {"ten" , "twenty" , "thirty" , "fourty" , "fifty" , "sixty" , "seventy" , "eighty" , "ninety" } ;

            if (number/100000000 != 0)
            {
                numberText += zereoNine[number/100000000] + " hundred and " ;
                number = number - ((number/100000000) * 100000000) ;
                Convert.ToInt32(numberInp) ;
                string myString = number.ToString();
                numbInpArr = myString.ToCharArray() ; 
            }

            if (number/10000000 != 0)
            {
                numberText += tenHundred[(number/10000000) -1] + " " ;
                number = number - ((number/10000000) * 10000000) ;
                Convert.ToInt32(numberInp) ;
                string myString = number.ToString();
                numbInpArr = myString.ToCharArray() ; 
            }

            if (number/1000000 != 0)
            {
                numberText += zereoNine[number/1000000] + " million " ;
                number = number - ((number/1000000) * 1000000) ;
                Convert.ToInt32(numberInp) ;
                string myString = number.ToString();
                numbInpArr = myString.ToCharArray() ;
            }

            if (number/100000 != 0)
            {
                numberText += zereoNine[number/100000] + " hundred and " ;
                number = number - ((number/100000) * 100000) ;
                Convert.ToInt32(numberInp) ;
                string myString = number.ToString();
                numbInpArr = myString.ToCharArray() ;
            }

            if (number/10000 != 0)
            {
                numberText += tenHundred[(number/10000)-1] + " " ;
                number = number - ((number/10000) * 10000) ;
                Convert.ToInt32(numberInp) ;
                string myString = number.ToString();
                numbInpArr = myString.ToCharArray() ;
            }

            if (number/1000 != 0)
            {
                numberText += " " + zereoNine[number/1000] + " thousand " ;
                number = number - ((number/1000) * 1000) ;
                Convert.ToInt32(numberInp) ;
                string myString = number.ToString();
                numbInpArr = myString.ToCharArray() ;
            } 

            int num = Convert.ToInt32(numberInp.Length) ;
            if ( num > 2)
            {
                int i = name.ConvertToInt(numbInpArr[0] ) ;
                int n = name.ConvertToInt(numbInpArr[1] ) ;
                int d = name.ConvertToInt(numbInpArr[2] ) ;
                numberText += zereoNine[i] + " hundred " ;

                if ( numberInp[1] != 0  ||  numberInp[2] != 0 )
                {
                    numberText += " and " ;
                }

                if( numberInp[1] != 0 )
                {
                    numberText += " " + tenHundred[n - 1]  ;
                }

                if( numberInp[2] != 0 )
                {
                    numberText +=  " " + zereoNine[d]  ;
                }
            }

            if (number < 10)
            {
                numberText += zereoNine[number] ;
            }

            if (number < 100 && number > 9) // between 10 - 99
            {
                Console.WriteLine("hello.. number is between 10-99. Your number is " + number ) ;
                int numIndex1 = name.ConvertToInt(numbInpArr[0]) ; // this converts the number character to an integer... 
                int numIndex2 = name.ConvertToInt(numbInpArr[1]) ;
                    numberText += tenHundred[numIndex1 -1] ;
            }
            Console.WriteLine("CONVERSION (" + numberInp + ") : " + numberText) ;
        }
    }
}
