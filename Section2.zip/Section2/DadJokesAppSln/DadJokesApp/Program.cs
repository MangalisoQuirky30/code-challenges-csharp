﻿using System;
using System.Threading.Tasks;
using DadJokesLibrary;

namespace DadJokesApp
{
    class Program
    {
        static async Task Main(string[] args)
        {
            JokeGenerator joke = new JokeGenerator();
            string dadJoke = await joke.GetRandomJokeAsync();
            Console.WriteLine(dadJoke);
            Console.WriteLine("Hello World!");
        }
    }
}

